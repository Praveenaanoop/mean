var mongoose=require('mongoose');
var Schema=mongoose.Schema;
var dressSchema=new Schema({did:{type:Number},dname:{type:String},color:{type:String},designer:{type:String},image:{type:String}});
module.exports=mongoose.model("dress",dressSchema);