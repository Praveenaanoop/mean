var express=require('express')
const app=express()
var port=process.env.PORT||5000
app.set("view engine","ejs")
var bodyparser=require('body-parser')
app.use(bodyparser.urlencoded({extended:true}))
var path = require('path');
app.use("/public",express.static(path.join(__dirname, 'public')));
var mongoose=require('mongoose')
var db="mongodb://praveena_anoop_90:12345@cluster0-shard-00-00-4oyg0.mongodb.net:27017,cluster0-shard-00-01-4oyg0.mongodb.net:27017,cluster0-shard-00-02-4oyg0.mongodb.net:27017/mydb?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true"
mongoose.connect(db,function(err){
    console.log(err)
})
var dress=require("./models/object")
var fileupload=require('express-fileupload')
app.use(fileupload())
app.get("/",function(req,res){
    res.render("home")
})
app.get("/dress",function(req,res){
    res.render("home")
})
app.get("/edit",function(req,res){
    res.render("update")
})
app.get("/del",function(req,res){
    res.render("delete")
})
app.post("/remove",function(req,res){
    dress.deleteOne({"did":req.body.ino},function(err,result){
if(err)
    {
        res.send(err)
    }
    else{
        res.send("deleted successfully")
    }
    })
})
app.post("/update",function(req,res){
    dress.findOne({},function(err,ddata){
        ddata.did=req.body.ino
        ddata.dname=req.body.iname
        ddata.color=req.body.icol
        ddata.designer=req.body.ides
        ddata.image=req.body.sample
        ddata.save(function(err){
            if(err){
                res.send(err)
            }
            else{
                res.send("updated")
            }
        })
    })
})
app.get("/view",function(req,res){
    dress.find({},function(err,result){
        if(err){
            res.send(err)
        }
        else{
            res.render("view",{data:result})
        }
    })
})
app.get("/item",function(req,res){
    res.render("insert")
})
app.post("/insert",function(req,res){
 var d1=new dress
 d1.did=parseInt(req.body.ino)
 d1.dname=req.body.iname
 d1.color=req.body.icol
 d1.designer=req.body.ides
 let sam=req.files.sample
 d1.image=sam.name
 sam.mv(__dirname+"/public/images/"+sam.name)
     console.log(sam.name);
 d1.save(function(err,result){
     if(err)
     {
         console.log(err)
     }
     else{
         res.send("successfully inserted")
     }
 })
})












app.listen(port,function(req,res){
    console.log("server started")
})
